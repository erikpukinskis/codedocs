import type HTMLElement from '../html-element/HTMLElement.js';
import type Node from '../node/Node.js';
import type SVGElement from '../svg-element/SVGElement.js';
/**
 * HTMLElement utility.
 */
export default class HTMLElementUtility {
    /**
     * Triggers a blur event.
     *
     * @param element Element.
     */
    static blur(element: HTMLElement | SVGElement): void;
    /**
     * Triggers a focus event.
     *
     * @param element Element.
     */
    static focus(element: HTMLElement | SVGElement): void;
    /**
     * Places a collapsed selection at the first editable text node in a contenteditable root.
     *
     * @param root Contenteditable root element.
     */
    static placeCaretInContentEditable(root: HTMLElement): void;
    /**
     * Returns the outermost contenteditable root for a node.
     *
     * @param node Node.
     * @returns Contenteditable root element, or null if none exists.
     */
    static getContentEditableRoot(node: Node): HTMLElement | null;
    /**
     * Returns the first Text node that is not inside a contenteditable=false subtree.
     *
     * @param root Root element to search within.
     * @returns First editable Text node, or null if none exists.
     */
    private static findFirstEditableTextNode;
    /**
     * Returns whether an element or any of its ancestors has the inert attribute.
     *
     * @param element Element to check.
     * @returns True if the element is in an inert tree.
     */
    private static isInert;
}
//# sourceMappingURL=HTMLElementUtility.d.ts.map