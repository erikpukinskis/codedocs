import type IBrowserSettings from './types/IBrowserSettings.js';
import BrowserContext from './BrowserContext.js';
import type IOptionalBrowserSettings from './types/IOptionalBrowserSettings.js';
import BrowserSettingsFactory from './BrowserSettingsFactory.js';
import type BrowserPage from './BrowserPage.js';
import type IBrowser from './types/IBrowser.js';
import type IConsole from '../console/IConsole.js';
import BrowserExceptionObserver from './utilities/BrowserExceptionObserver.js';
import * as PropertySymbol from '../PropertySymbol.js';
import BrowserErrorCaptureEnum from './enums/BrowserErrorCaptureEnum.js';

/**
 * Browser.
 */
export default class Browser implements IBrowser {
	public readonly contexts: BrowserContext[];
	public readonly settings: IBrowserSettings;
	public readonly console: IConsole | null;
	public [PropertySymbol.exceptionObserver]: BrowserExceptionObserver | null = null;

	/**
	 * Constructor.
	 *
	 * @param [options] Options.
	 * @param [options.settings] Browser settings.
	 * @param [options.console] Console.
	 */
	constructor(options?: { settings?: IOptionalBrowserSettings; console?: IConsole }) {
		this.console = options?.console || null;
		this.settings = BrowserSettingsFactory.createSettings(options?.settings);
		if (this.settings.errorCapture === BrowserErrorCaptureEnum.processLevel) {
			this[PropertySymbol.exceptionObserver] = new BrowserExceptionObserver();
		}
		this.contexts = [new BrowserContext(this)];
	}

	/**
	 * Returns true if the browser is closed.
	 *
	 * @returns True if the browser is closed.
	 */
	public get closed(): boolean {
		return this.contexts.length === 0;
	}

	/**
	 * Returns the default context.
	 *
	 * @returns Default context.
	 */
	public get defaultContext(): BrowserContext {
		if (this.contexts.length === 0) {
			throw new Error('No default context. The browser has been closed.');
		}
		return this.contexts[0];
	}

	/**
	 * Aborts all ongoing operations and destroys the browser.
	 */
	public async close(): Promise<void> {
		if (this.contexts.length === 0) {
			return;
		}
		const contexts = this.contexts;
		(<BrowserContext[]>this.contexts) = [];
		await Promise.all(contexts.map((context) => context.close()));
	}

	/**
	 * Returns a promise that is resolved when all resources has been loaded, fetch has completed, and all async tasks such as timers are complete.
	 *
	 * @returns Promise.
	 */
	public async waitUntilComplete(): Promise<void> {
		if (this.contexts.length === 0) {
			throw new Error('No default context. The browser has been closed.');
		}
		await Promise.all(this.contexts.map((page) => page.waitUntilComplete()));
	}

	/**
	 * Aborts all ongoing operations.
	 */
	public abort(): Promise<void> {
		// Using Promise instead of async/await to prevent microtask
		return new Promise((resolve, reject) => {
			if (!this.contexts.length) {
				resolve();
				return;
			}
			Promise.all(this.contexts.slice().map((context) => context.abort()))
				.then(() => resolve())
				.catch((error) => reject(error));
		});
	}

	/**
	 * Creates a new incognito context.
	 *
	 * @returns Context.
	 */
	public newIncognitoContext(): BrowserContext {
		if (this.contexts.length === 0) {
			throw new Error('No default context. The browser has been closed.');
		}
		const context = new BrowserContext(this);
		this.contexts.push(context);
		return context;
	}

	/**
	 * Creates a new page.
	 *
	 * @returns Page.
	 */
	public newPage(): BrowserPage {
		if (this.contexts.length === 0) {
			throw new Error('No default context. The browser has been closed.');
		}
		return this.contexts[0].newPage();
	}
}
